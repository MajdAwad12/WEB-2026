// attendance.js
// מסך סימון נוכחות – למשגיח, עם Fake data בלבד וסימולציה ל-QR

const activeExitTimers = {}; // key: index, value: setInterval id

document.addEventListener("DOMContentLoaded", () => {
  const tableBody          = document.getElementById("studentsTableBody");
  const examInfoEl         = document.getElementById("examShortInfo");

  const countPresentEl     = document.getElementById("countPresent");
  const countOutEl         = document.getElementById("countOut");
  const countAbsentEl      = document.getElementById("countAbsent");
  const countNotArrivedEl  = document.getElementById("countNotArrived");

  const btnMarkAllPresent  = document.getElementById("btnMarkAllPresent");
  const btnResetAll        = document.getElementById("btnResetAll");

  const scanSelect         = document.getElementById("scanStudentSelect");
  const btnScanSim         = document.getElementById("btnScanSim");
  const scanInfo           = document.getElementById("scanInfo");

  // רשימות זמנים דמיוניים לסימולציה
  const simArrivalTimes = ["09:00", "09:03", "09:06", "09:09", "09:12", "09:15", "09:18", "09:21"];
  let simArrivalIndex = 0;

  const simExitTimes = ["09:30","09:55","10:00","10:15", "10:40", "11:00", "11:10","11:15","11:23","11:35","11:55","12:00"];
  let simExitIndex = 0;

  function getNextArrivalTime() {
    const t = simArrivalTimes[Math.min(simArrivalIndex, simArrivalTimes.length - 1)];
    simArrivalIndex++;
    return t;
  }

  function getNextExitTime() {
    const t = simExitTimes[Math.min(simExitIndex, simExitTimes.length - 1)];
    simExitIndex++;
    return t;
  }

  // בדיקת Fake data – רשימת סטודנטים
  if (typeof currentExamStudents === "undefined" || !Array.isArray(currentExamStudents)) {
    console.error("currentExamStudents is not defined or not an array.");
    if (examInfoEl) {
      examInfoEl.innerHTML = `
        <p class="text-red-600 text-sm">
          Error: currentExamStudents is missing from fakeData.js
        </p>
      `;
    }
    return;
  }

  // לוודא שלכל סטודנט יש שדות יציאות + שדות חריגים/זמנים
  currentExamStudents.forEach(st => {
    if (!Array.isArray(st.exits)) st.exits = [];
    if (typeof st.currentExitStart !== "number") st.currentExitStart = null;
    if (!("arrivalTime" in st)) st.arrivalTime = null;
    if (!("finalExitTime" in st)) st.finalExitTime = null;
    if (!("isLate" in st)) st.isLate = false;
    if (!("isEarlyLeave" in st)) st.isEarlyLeave = false;
  });

  // פרטי הבחינה – אחד מתחת לשני
  if (typeof currentExamStatus !== "undefined" && examInfoEl) {
    examInfoEl.innerHTML = `
      <p><span class="font-semibold">Course:</span> ${currentExamStatus.courseName}</p>
      <p><span class="font-semibold">Course number:</span> ${currentExamStatus.courseNumber}</p>
      <p><span class="font-semibold">Room:</span> ${currentExamStatus.room}</p>
      <p><span class="font-semibold">Supervisor:</span> ${currentExamStatus.supervisor}</p>
      <p><span class="font-semibold">Exam time:</span> ${currentExamStatus.startTime}–${currentExamStatus.endTime}</p>
      <p><span class="font-semibold">Total students in list:</span> ${currentExamStudents.length}</p>
    `;
  }

  // מילוי ה-dropdown של הסריקה (סימולציה)
  function populateScanSelect() {
    if (!scanSelect) return;
    scanSelect.innerHTML = "";
    currentExamStudents.forEach((st, index) => {
      const opt = document.createElement("option");
      opt.value = String(index);
      opt.textContent = `[${st.seat}] ${st.name} – ${st.id}`;
      scanSelect.appendChild(opt);
    });
  }

  // פונקציה לעדכון הכרטיסים למעלה
  function updateCounters() {
    let present = 0;
    let out     = 0;
    let absent  = 0;
    let notArr  = 0;

    currentExamStudents.forEach(st => {
      switch (st.status) {
        case "Present":
          present++;
          break;
        case "Out Of Room":
          out++;
          break;
        case "Absent":
          absent++;
          break;
        default: // "Not Arrived" או כל דבר אחר
          notArr++;
          break;
      }
    });

    if (countPresentEl)    countPresentEl.textContent    = present;
    if (countOutEl)        countOutEl.textContent        = out;
    if (countAbsentEl)     countAbsentEl.textContent     = absent;
    if (countNotArrivedEl) countNotArrivedEl.textContent = notArr;
  }

  // מחזיר מחלקות לצבע סטטוס
  function getStatusClasses(status) {
    switch (status) {
      case "Present":
        return "bg-emerald-50 text-emerald-700 border border-emerald-200";
      case "Out Of Room":
        return "bg-amber-50 text-amber-700 border border-amber-200";
      case "Absent":
        return "bg-rose-50 text-rose-700 border border-rose-200";
      case "Not Arrived":
      default:
        return "bg-gray-50 text-gray-700 border border-gray-200";
    }
  }

  function getDotClasses(status) {
    switch (status) {
      case "Present":
        return "bg-emerald-500";
      case "Out Of Room":
        return "bg-amber-500";
      case "Absent":
        return "bg-rose-500";
      case "Not Arrived":
      default:
        return "bg-gray-400";
    }
  }

  function formatDuration(ms) {
    if (!ms || ms < 0) ms = 0;
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }

  function startTimerFor(index) {
    // אם כבר יש טיימר – לא לפתוח עוד אחד
    if (activeExitTimers[index]) return;

    const timerEl = document.getElementById(`exitTimer-${index}`);
    if (!timerEl) return;

    function tick() {
      const st = currentExamStudents[index];
      if (!st || !st.currentExitStart) {
        clearInterval(activeExitTimers[index]);
        delete activeExitTimers[index];
        return;
      }
      const diffMs = Date.now() - st.currentExitStart;
      timerEl.textContent = formatDuration(diffMs);
    }

    tick();
    activeExitTimers[index] = setInterval(tick, 1000);
  }

  // ציור הטבלה
  function renderTable() {
    tableBody.innerHTML = "";

    currentExamStudents.forEach((student, index) => {
      const tr = document.createElement("tr");
      tr.className = "hover:bg-gray-50 transition";
      tr.dataset.index = index;

      const statusClasses = getStatusClasses(student.status);
      const dotClasses    = getDotClasses(student.status);

      // תגית הארכת זמן (אם יש)
      const extraTime = student.extraTimeMinutes || 0;
      const extraTimeBadge = extraTime
        ? `<span class="ml-2 text-[10px] px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
             +${extraTime} min
           </span>`
        : "";

      const exitsCount = student.exits ? student.exits.length : 0;
      let lastExitInfoText = "No exits yet";
      if (exitsCount > 0) {
        const last = student.exits[exitsCount - 1];
        lastExitInfoText = `Exits: ${exitsCount}, Last: ${formatDuration(last.durationMs)}`;
      }

      const hasOngoingExit = !!student.currentExitStart;

      // חריגים: איחור / עזיבה מוקדמת / יציאה ארוכה לשירותים
      const exceptionLabels = [];
      if (student.isLate)       exceptionLabels.push("Late arrival");
      if (student.isEarlyLeave) exceptionLabels.push("Early leave");

      // אם הייתה יציאה מעל 10 דקות – נחשב "Long bathroom exit"
      if (student.exits && student.exits.some(e => e.durationMs > 10 * 60 * 1000)) {
        exceptionLabels.push("Long bathroom exit");
      }

      const exceptionsHtml = exceptionLabels.length
        ? `<div class="flex flex-wrap gap-1">
             ${exceptionLabels
               .map(lbl => `
                 <span class="px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200 text-[10px]">
                   ${lbl}
                 </span>
               `)
               .join("")}
           </div>`
        : `<span class="text-[11px] text-gray-400">No exceptions</span>`;

      tr.innerHTML = `
        <td class="px-3 py-2 whitespace-nowrap text-gray-800">${student.seat}</td>
        <td class="px-3 py-2 whitespace-nowrap text-gray-700">${student.id}</td>
        <td class="px-3 py-2 whitespace-nowrap text-gray-700">
          ${student.name}
          ${extraTimeBadge}
          <div class="text-[11px] text-gray-400">
            Entry: ${student.arrivalTime || "--:--"} | Exit: ${student.finalExitTime || "--:--"}
          </div>
        </td>
        <td class="px-3 py-2 whitespace-nowrap">
          <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold ${statusClasses}">
            <span class="w-1.5 h-1.5 rounded-full mr-1 ${dotClasses}"></span>
            <span>${student.status}</span>
          </span>
        </td>
        <td class="px-3 py-2 whitespace-nowrap">
          <div class="flex flex-wrap gap-1">
            <button class="px-2 py-1 text-xs rounded-full border border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                    data-status-btn="Present">
              Present
            </button>
            <button class="px-2 py-1 text-xs rounded-full border border-rose-200 text-rose-700 hover:bg-rose-50"
                    data-status-btn="Absent">
              Left the Room
            </button>
            <button class="px-2 py-1 text-xs rounded-full border border-gray-300 text-gray-700 hover:bg-gray-100"
                    data-status-btn="Not Arrived">
              Not Arrived
            </button>
          </div>
        </td>
        <td class="px-3 py-2 whitespace-nowrap">
          <div class="flex flex-col gap-1 text-xs">
            <button
              class="px-2 py-1 rounded-full border border-amber-300
                     ${hasOngoingExit ? "bg-amber-100 text-amber-800" : "text-amber-700 hover:bg-amber-50"}"
              data-out-btn="toggle">
              ${hasOngoingExit ? "Student Back" : "Start Exit"}
            </button>
            <div class="text-[11px] text-gray-500">
              ${lastExitInfoText}
            </div>
            ${
              hasOngoingExit
                ? `<div class="text-[11px] font-mono text-amber-700" id="exitTimer-${index}">
                     00:00
                   </div>`
                : ""
            }
          </div>
        </td>
        <td class="px-3 py-2 whitespace-nowrap">
          ${exceptionsHtml}
        </td>
      `;

      tableBody.appendChild(tr);
    });

    // אחרי כל ציור – להתחיל/לעצור טיימרים לפי מצב
    currentExamStudents.forEach((st, index) => {
      if (st.currentExitStart) {
        startTimerFor(index);
      } else if (activeExitTimers[index]) {
        clearInterval(activeExitTimers[index]);
        delete activeExitTimers[index];
      }
    });

    // לעדכן כרטיסים
    updateCounters();
  }

  // שינוי סטטוס לסטודנט – ואח"כ רענון מלא
  function setStudentStatus(index, newStatus) {
    const st = currentExamStudents[index];
    if (!st) return;

    const prevStatus = st.status;
    if (prevStatus === newStatus) {
      renderTable();
      return;
    }

    // סימון שעת כניסה – בפעם הראשונה שהופך ל-Present
    if (newStatus === "Present" && !st.arrivalTime) {
      st.arrivalTime = getNextArrivalTime();

      // בדיקה אם מאוחר ביחס לשעת התחלת הבחינה (סימולציה לפי הערכים)
      if (currentExamStatus && currentExamStatus.startTime) {
        // כאן אין חישוב אמיתי, אבל אפשר להגיד:
        // אם הזמן הוא מעל 09:10 נחשב איחור לדוגמה
        const lateThreshold = "09:10";
        if (st.arrivalTime > lateThreshold) {
          st.isLate = true;
        }
      }
    }

    // סימון עזיבה מוקדמת – אם היה Present ועכשיו Absent
    if (prevStatus === "Present" && newStatus === "Absent") {
      if (!st.finalExitTime) {
        st.finalExitTime = getNextExitTime();
      }
      // אם יצא לפני 11:00 → Early leave, אם ב-11:00 או אחרי → לא חריג
      const earlyThreshold = "11:00";
      if (st.finalExitTime < earlyThreshold) {
        st.isEarlyLeave = true;
      } else {
        st.isEarlyLeave = false;
      }
    }

    st.status = newStatus;
    renderTable();
  }

  // האזנה לכפתורים בטבלה (Event Delegation)
  tableBody.addEventListener("click", (event) => {
    const row = event.target.closest("tr");
    if (!row) return;
    const index = Number(row.dataset.index);
    if (Number.isNaN(index)) return;

    const outBtn = event.target.closest("[data-out-btn]");
    if (outBtn) {
      const st = currentExamStudents[index];
      if (!st) return;

      // אם כרגע בחוץ – לחיצה = חזרה
      if (st.currentExitStart) {
        const end = Date.now();
        const durationMs = end - st.currentExitStart;
        if (!Array.isArray(st.exits)) st.exits = [];
        st.exits.push({
          start: st.currentExitStart,
          end,
          durationMs
        });
        st.currentExitStart = null;
        setStudentStatus(index, "Present");
      } else {
        // התחלת יציאה
        st.currentExitStart = Date.now();
        setStudentStatus(index, "Out Of Room");
      }
      return; // לא להמשיך לעיבוד כפתורי סטטוס
    }

    const btn = event.target.closest("[data-status-btn]");
    if (!btn) return;

    const newStatus = btn.getAttribute("data-status-btn");
    setStudentStatus(index, newStatus);
  });

  // כפתור "Mark all as Present"
  if (btnMarkAllPresent) {
    btnMarkAllPresent.addEventListener("click", () => {
      currentExamStudents.forEach((st, i) => {
        st.status = "Present";
        st.currentExitStart = null;
        if (!st.arrivalTime) {
          st.arrivalTime = getNextArrivalTime();
        }
        st.isLate = false;      // בתרגיל – נניח שהם הגיעו בזמן
        st.isEarlyLeave = false;
        if (activeExitTimers[i]) {
          clearInterval(activeExitTimers[i]);
          delete activeExitTimers[i];
        }
      });
      renderTable();
    });
  }

  // כפתור "Reset to Not Arrived"
  if (btnResetAll) {
    btnResetAll.addEventListener("click", () => {
      currentExamStudents.forEach((st, i) => {
        st.status = "Not Arrived";
        st.currentExitStart = null;
        st.exits = [];
        st.arrivalTime = null;
        st.finalExitTime = null;
        st.isLate = false;
        st.isEarlyLeave = false;
        if (activeExitTimers[i]) {
          clearInterval(activeExitTimers[i]);
          delete activeExitTimers[i];
        }
      });
      renderTable();
      if (scanInfo) {
        scanInfo.textContent = "No scan yet (simulation).";
      }
      simArrivalIndex = 0;
      simExitIndex = 0;
    });
  }

  // כפתור סריקה דמיונית – סימולציה
  if (btnScanSim && scanSelect && scanInfo) {
    btnScanSim.addEventListener("click", () => {
      const idx = Number(scanSelect.value);
      if (Number.isNaN(idx)) return;
      const st = currentExamStudents[idx];
      if (!st) return;

      // אם כבר מסומן נוכח – רק נעדכן את ההודעה
      if (st.status === "Present") {
        if (!st.arrivalTime) {
          st.arrivalTime = getNextArrivalTime();
        }
        scanInfo.textContent =
          `Simulation: ${st.id} – ${st.name} is already Present (entry: ${st.arrivalTime}).`;
        return;
      }

      // אם הוא Not Arrived / Absent – נסמן אותו כנוכח בסימולציה
      setStudentStatus(idx, "Present");
      scanInfo.textContent =
        `Simulation: scanned ${st.id} – ${st.name} at ${st.arrivalTime}.`;
    });
  }

  // מילוי ה-dropdown פעם אחת בהתחלה
  populateScanSelect();

  // ציור ראשון – ברירת מחדל
  renderTable();
});
