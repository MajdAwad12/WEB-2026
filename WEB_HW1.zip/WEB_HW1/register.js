// register.js
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');

    registerForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const fullname = document.getElementById('fullname').value.trim();
        const email = document.getElementById('email').value.trim();
        const username = document.getElementById('username').value.trim();
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        const role = document.getElementById('role').value;
        const terms = document.getElementById('terms').checked;

        if (!fullname || !email || !username || !password || !role) {
            alert('Please fill all required fields!');
            return;
        }

        if (!terms) {
            alert('You must agree to the Terms of Service!');
            return;
        }

        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }

        if (isUsernameTaken(username)) {
            alert('Username already exists!');
            return;
        }

        if (addNewAccount(fullname, email, username, password, role)) {
            alert('Account created successfully! You can now login.');
            window.location.href = 'login.html';
        } else {
            alert('Error creating account!');
        }
    });

    // Live password match check
    confirmPasswordInput.addEventListener('input', function () {
        if (passwordInput.value !== confirmPasswordInput.value) {
            confirmPasswordInput.style.borderColor = 'red';
        } else {
            confirmPasswordInput.style.borderColor = '';
        }
    });
});


