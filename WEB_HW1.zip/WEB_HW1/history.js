// history.js

document.addEventListener('DOMContentLoaded', () => {
  const tbody = document.getElementById('historyTableBody');

  if (!tbody) {
    console.error('historyTableBody element not found in DOM.');
    return;
  }

  if (typeof activityHistory === 'undefined') {
    console.error('activityHistory is not defined. Make sure it exists in fakeData.js');
    return;
  }

  activityHistory.forEach((item) => {
    const tr = document.createElement('tr');
    tr.className = 'hover:bg-gray-50 transition';

    tr.innerHTML = `
      <td class="py-3 px-4 text-sm font-medium ${item.actionClass}">${item.action}</td>
      <td class="py-3 px-4 text-sm text-gray-600">${item.description}</td>
      <td class="py-3 px-4 text-sm text-gray-500">${item.time}</td>
      <td class="py-3 px-4 text-sm text-gray-500">${item.date}</td>
    `;

    tbody.appendChild(tr);
  });
});
