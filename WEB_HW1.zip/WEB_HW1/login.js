// login.js
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const errorMessage = document.getElementById('errorMessage');
  const errorTitle = document.getElementById('errorTitle');
  const errorText = document.getElementById('errorText');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const submitButton = loginForm ? loginForm.querySelector('button[type="submit"]') : null;

  // אם fakeAccounts לא נטען → עצירה
  if (typeof fakeAccounts === "undefined") {
    console.error("fakeAccounts array not loaded. Check fakeData.js path.");
    alert("System Error: Fake Data Not Loaded.");
    return;
  }

  // פונקציית LOGIN מובנית כאן (במקום auth.js)
  function validateLogin(username, password) {
    return fakeAccounts.find(
      acc =>
        acc.username.toLowerCase() === username.toLowerCase() &&
        acc.password === password
    ) || null;
  }

  // טעינת Remember Me
  const rememberedUsername = localStorage.getItem('rememberedUsername');
  if (rememberedUsername) {
    usernameInput.value = rememberedUsername;
    if (rememberCheckbox) rememberCheckbox.checked = true;
  }

  // הצגת שגיאה
  function showError(title, message) {
    errorTitle.textContent = title;
    errorText.textContent = message;
    errorMessage.classList.remove('hidden');

    usernameInput.classList.add('border-red-500', 'shake');
    passwordInput.classList.add('border-red-500', 'shake');

    setTimeout(() => {
      usernameInput.classList.remove('shake');
      passwordInput.classList.remove('shake');
    }, 500);

    if (submitButton) submitButton.disabled = false;

    usernameInput.focus();
  }

  // הסתרת שגיאה
  function hideError() {
    errorMessage.classList.add('hidden');
    usernameInput.classList.remove('border-red-500');
    passwordInput.classList.remove('border-red-500');
  }

  usernameInput.addEventListener('input', hideError);
  passwordInput.addEventListener('input', hideError);

  // הגשת הטופס
  loginForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    // ולידציה בסיסית
    if (!username || !password) {
      showError('Missing Information', 'Please enter both username and password.');
      return;
    }

    // מניעת double click
    if (submitButton) submitButton.disabled = true;

    const account = validateLogin(username, password);

    if (account) {
      hideError();

      // שמירת משתמש מחובר
      localStorage.setItem('currentUser', JSON.stringify(account));


      // אנימציית הצלחה
      submitButton.textContent = 'Success! Redirecting...';
      submitButton.classList.remove('bg-indigo-600', 'hover:bg-indigo-700');
      submitButton.classList.add('bg-green-600', 'hover:bg-green-700');

      // מעבר לדף הבית
      setTimeout(() => {
        window.location.href = 'HomePage.html';
      }, 1000);

    } else {
      showError(
        'Authentication Failed',
        'The username or password you entered is incorrect.'
      );
    }
  });

});
