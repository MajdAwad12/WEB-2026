// dashboard.js
// Simple "live" exam dashboard with fixed-time simulation

document.addEventListener("DOMContentLoaded", () => {
  const alertsList       = document.getElementById("alertsList");
  const currentExamInfo  = document.getElementById("currentExamInfo");
  const statusSummary    = document.getElementById("statusSummary");
  const incidentsSummary = document.getElementById("incidentsSummary");

  const todayDateEl   = document.getElementById("todayDate");
  const currentTimeEl = document.getElementById("currentTime");
  const timeLeftEl    = document.getElementById("remainingtime");

  // 1. Today date (real)
  if (todayDateEl) {
    const today = new Date();
    todayDateEl.textContent = today.toLocaleDateString("en-GB");
  }

  // 2. Check fake data exists
  if (typeof currentExamStatus === "undefined") {
    if (currentExamInfo) {
      currentExamInfo.innerHTML = `
        <p class="text-red-600 text-sm">
          Error: current exam data is missing from fakeData.js
        </p>
      `;
    }
    if (statusSummary) {
      statusSummary.textContent =
        "Cannot show student status without exam data.";
    }
    if (incidentsSummary) {
      incidentsSummary.textContent =
        "Cannot show incidents without exam data.";
    }
    return;
  }

  const exam = currentExamStatus;

  // 3. Time simulation: now = 11:00, time remaining = endTime - 11:00

  function parseTimeToDate(timeStr) {
    if (!timeStr || typeof timeStr !== "string" || !timeStr.includes(":")) {
      return null;
    }
    const [h, m] = timeStr.split(":").map(Number);
    if (isNaN(h) || isNaN(m)) return null;

    const d = new Date();
    d.setHours(h, m, 0, 0);
    return d;
  }

  const simulatedNowStr = "10:00";

  if (currentTimeEl) {
    currentTimeEl.textContent = simulatedNowStr;
  }

  if (timeLeftEl) {
    if (!exam.endTime) {
      timeLeftEl.textContent = "End time missing in fakeData.js";
    } else {
      const end = parseTimeToDate(exam.endTime);
      const now = parseTimeToDate(simulatedNowStr);

      if (!end || !now) {
        timeLeftEl.textContent = "Invalid time format";
      } else {
        let diff = end - now;

        if (diff <= 0) {
          timeLeftEl.textContent = "Exam finished";
        } else {
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const mins  = Math.floor((diff / (1000 * 60)) % 60);

          if (hours <= 0) {
            timeLeftEl.textContent = `${mins} min`;
          } else {
            timeLeftEl.textContent = `${hours}h ${mins}m`;
          }
        }
      }
    }
  }

  // 4. Overview card
  if (currentExamInfo) {
    currentExamInfo.innerHTML = `
      <p><span class="font-semibold">Course:</span> ${exam.courseName} (${exam.courseNumber})</p>
      <p><span class="font-semibold">Room:</span> ${exam.room}</p>
      <p><span class="font-semibold">Supervisor:</span> ${exam.supervisor}</p>
      <p>
        <span class="font-semibold">Exam time:</span> ${exam.startTime}–${exam.endTime}
        <span class="text-xs text-gray-500 ml-1">(now: ${simulatedNowStr})</span>
      </p>
      <p><span class="font-semibold">Total students:</span> ${exam.totalStudents}</p>
    `;
  }

  // 5. Status chart
  const statusCtx = document.getElementById("statusBar")?.getContext("2d");

  const statusData = [exam.present, exam.tempOut, exam.absent];
  const total = exam.totalStudents || (exam.present + exam.tempOut + exam.absent);

  function pct(value) {
    if (!total || total === 0) return "0%";
    const p = (value / total) * 100;
    return p.toFixed(1) + "%";
  }

  if (statusCtx) {
    new Chart(statusCtx, {
      type: "bar",
      data: {
        labels: ["Present", "Out Of Room", "Absent"],
        datasets: [
          {
            label: "Number of students",
            data: statusData,
            backgroundColor: ["#4f46e5", "#f59e0b", "#f97373"]
          }
        ]
      },
      options: {
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 5 }
          }
        }
      }
    });
  }

  if (statusSummary) {
    statusSummary.innerHTML = `
      <p class="font-semibold mb-1">Short summary:</p>
      <ul class="list-disc list-inside space-y-1">
        <li><span class="font-semibold">Present:</span> ${exam.present} students are now inside the room (${pct(exam.present)}).</li>
        <li><span class="font-semibold">Out Of Room:</span> ${exam.tempOut} students are now out of the room for a short break (${pct(exam.tempOut)}).</li>
        <li><span class="font-semibold">Did not arrive:</span> ${exam.absent} students did not come to the exam (${pct(exam.absent)}).</li>
      </ul>
    `;
  }

  // 6. Incidents chart
  const inc = exam.incidents || {
    longBathroom: 0,
    lateArrival: 0,
    earlyLeave: 0,
    idProblem: 0
  };

  const incidentsCtx = document.getElementById("incidentsBar")?.getContext("2d");

  const incidentsValues = [
    inc.longBathroom,
    inc.lateArrival,
    inc.earlyLeave,
    inc.idProblem
  ];

  const totalIncidents = incidentsValues.reduce((a, b) => a + b, 0);

  if (incidentsCtx) {
    new Chart(incidentsCtx, {
      type: "bar",
      data: {
        labels: ["Long bathroom", "Late arrival", "Early leave", "ID problem"],
        datasets: [
          {
            label: "Number of incidents",
            data: incidentsValues,
            backgroundColor: ["#10b981", "#3b82f6", "#a855f7", "#ef4444"]
          }
        ]
      },
      options: {
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    });
  }

  if (incidentsSummary) {
    if (totalIncidents === 0) {
      incidentsSummary.innerHTML = `
        <p class="font-semibold mb-1">Incidents in this exam:</p>
        <p>No special incidents were reported. The exam looks normal.</p>
      `;
    } else {
      incidentsSummary.innerHTML = `
        <p class="font-semibold mb-1">Incidents in this exam:</p>
        <ul class="list-disc list-inside space-y-1">
          <li><span class="font-semibold">Long bathroom:</span> ${inc.longBathroom} case(s) of students staying outside too long.</li>
          <li><span class="font-semibold">Late arrivals:</span> ${inc.lateArrival} student(s) arrived late.</li>
          <li><span class="font-semibold">Early leave:</span> ${inc.earlyLeave} student(s) left earlier than expected.</li>
          <li><span class="font-semibold">ID problems:</span> ${inc.idProblem} case(s) where ID did not match.</li>
        </ul>
      `;
    }
  }

  // 7. Alerts
  const alerts = [];

  alerts.push({
    type: "info",
    message: `Exam "${exam.courseName}" is now running in room ${exam.room}.`
  });

  alerts.push({
    type: "info",
    message: `Total students: ${exam.totalStudents}. In room: ${exam.present}.`
  });

  if (exam.tempOut > 0) {
    alerts.push({
      type: "warning",
      message: `${exam.tempOut} student(s) are currently Out Of Room (bathroom / short break). Please follow their return.`
    });
  }

  if (inc.longBathroom > 0) {
    alerts.push({
      type: "warning",
      message: `${inc.longBathroom} student(s) stayed in the bathroom longer than allowed. Please check them.`
    });
  }

  if (inc.lateArrival > 0) {
    alerts.push({
      type: "info",
      message: `${inc.lateArrival} late arrival(s) were registered in this exam.`
    });
  }

  if (inc.idProblem > 0) {
    alerts.push({
      type: "warning",
      message: `There was at least one ID problem. Please verify the student and, if needed, report to the administration.`
    });
  }

  alerts.push({
    type: "info",
    message: `Close to the end of the exam, please remember to say: "10 minutes left".`
  });

  if (alerts.length === 0) {
    alerts.push({
      type: "ok",
      message: "No alerts at the moment. The exam session looks stable."
    });
  }

  if (alertsList) {
    alerts.forEach(alert => {
      const li = document.createElement("li");

      let colorClasses = "bg-indigo-50 text-indigo-800 border-indigo-100";
      let icon = "ℹ️";

      if (alert.type === "warning") {
        colorClasses = "bg-amber-50 text-amber-800 border-amber-100";
        icon = "⚠️";
      } else if (alert.type === "ok") {
        colorClasses = "bg-emerald-50 text-emerald-800 border-emerald-100";
        icon = "✅";
      }

      li.className = `flex items-start gap-2 p-3 rounded-lg border ${colorClasses}`;

      li.innerHTML = `
        <span class="mt-0.5 text-lg">${icon}</span>
        <p class="text-sm">${alert.message}</p>
      `;

      alertsList.appendChild(li);
    });
  }
});
