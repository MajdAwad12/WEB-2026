// dashboard.js
// משתמש ב-dashboardStats וב-examsData מתוך fakeData.js

document.addEventListener("DOMContentLoaded", () => {
  const statsContainer = document.getElementById("statsCards");
  const examsList = document.getElementById("dashboardExamsList");

  // יצירת כרטיסי סטטיסטיקה
  const stats = [
    { label: "Total Exams", value: dashboardStats.totalExams },
    { label: "Total Students", value: dashboardStats.totalStudents },
    { label: "Exams Today", value: dashboardStats.upcomingToday },
    { label: "Active Supervisors", value: dashboardStats.activeSupervisors }
  ];

  stats.forEach(stat => {
    const card = document.createElement("div");
    card.className =
      "bg-white rounded-xl shadow p-4 flex flex-col justify-between";

    card.innerHTML = `
      <p class="text-xs text-gray-500 uppercase tracking-wide">${stat.label}</p>
      <p class="text-2xl font-bold text-gray-800 mt-2">${stat.value}</p>
    `;

    statsContainer.appendChild(card);
  });

  // רשימת בחינות קצרה
  examsData.slice(0, 3).forEach(exam => {
    const li = document.createElement("li");
    li.className = "flex items-center justify-between";

    li.innerHTML = `
      <span>${exam.courseName} (${exam.courseNumber})</span>
      <span class="text-gray-500 text-xs">${exam.date} • ${exam.time} • ${exam.room}</span>
    `;

    examsList.appendChild(li);
  });
});
