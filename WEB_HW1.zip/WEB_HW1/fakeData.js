// fakeData.js

const fakeAccounts = [
    {
        username: "Ali",
        password: "ali123",
        fullname: "Ali Hijazi",
        email: "ali@example.com",
        role: "supervisor"
    },
    {
        username: "Majd",
        password: "majd456",
        fullname: "Majd Awad",
        email: "majd@example.com",
        role: "admin"
    },
    {
        username: "Aya",
        password: "aya789",
        fullname: "Aya Kharma",
        email: "aya@example.com",
        role: "lecturer"
    }
];

const examsData = [
  { id: 1, courseName: "Linear Algebra", courseNumber: "MATH101", date: "2025-01-12", time: "09:00", room: "B301", supervisor: "Majd Awad", studentsCount: 45 },
  { id: 2, courseName: "Web Programming", courseNumber: "CS202", date: "2025-01-15", time: "13:00", room: "A204", supervisor: "Eli Cohen", studentsCount: 60 },
  { id: 3, courseName: "Databases", courseNumber: "CS303", date: "2025-02-01", time: "10:00", room: "C112", supervisor: "Barak Levi", studentsCount: 50 },
  { id: 4, courseName: "Operating Systems", courseNumber: "CS305", date: "2025-01-20", time: "11:00", room: "D210", supervisor: "Ayala Ben-David", studentsCount: 52 },
  { id: 5, courseName: "Software Engineering", courseNumber: "CS310", date: "2025-01-22", time: "14:00", room: "A110", supervisor: "Yael Shalem", studentsCount: 47 },
  { id: 6, courseName: "Machine Learning", courseNumber: "CS450", date: "2025-02-10", time: "14:00", room: "E102", supervisor: "Tamar Weiss", studentsCount: 35 },
  { id: 7, courseName: "Computer Networks", courseNumber: "CS330", date: "2025-01-25", time: "08:30", room: "C210", supervisor: "Daniel Peretz", studentsCount: 48 },
  { id: 8, courseName: "Data Structures", courseNumber: "CS220", date: "2025-01-28", time: "12:00", room: "B115", supervisor: "Eitan Mor", studentsCount: 55 },
  { id: 9, courseName: "Software Testing", courseNumber: "CS340", date: "2025-02-14", time: "15:00", room: "A305", supervisor: "Maya Armon", studentsCount: 42 },
  { id: 10, courseName: "Cyber Security", courseNumber: "CS480", date: "2025-02-18", time: "09:00", room: "F204", supervisor: "Noa Azulay", studentsCount: 38 }
];

const currentExamStatus = {
  courseName: "Web Programming",
  courseNumber: "CS202",
  room: "A204",
  supervisor: "Eli Cohen",
  startTime: "09:00",
  endTime: "12:00",   // Exam ends at 12:00
  currentTime: "10:30", // Not used in calculation (we simulate 11:00)
  totalStudents: 60,
  present: 52,
  tempOut: 3,
  absent: 5,
  incidents: {
    longBathroom: 1,
    lateArrival: 3,
    earlyLeave: 0,
    idProblem: 1
  }
};


const activityHistory = [
  { action: "User Registration", actionClass: "text-indigo-600", description: "New supervisor Alex registered", time: "08:15", date: "2023-10-15" },
  { action: "Exam Selection", actionClass: "text-green-600", description: "Selected 'Advanced Mathematics'", time: "09:00", date: "2023-10-15" },
  { action: "Bot Interaction", actionClass: "text-blue-600", description: "Bot sent important timing alert", time: "09:15", date: "2023-10-15" },
  { action: "Exam Communication", actionClass: "text-purple-600", description: "Supervisor sent status update", time: "09:30", date: "2023-10-15" },
  { action: "Bathroom Permission", actionClass: "text-amber-600", description: "Permission granted to student Ofer", time: "09:32", date: "2023-10-15" },
  { action: "Student Return", actionClass: "text-emerald-600", description: "Student Ofer returned", time: "09:35", date: "2023-10-15" },
  { action: "Time Extension", actionClass: "text-orange-600", description: "Extra 15 minutes added", time: "10:20", date: "2023-10-15" },
  { action: "Safety Alert", actionClass: "text-red-600", description: 'System alert: "10 minutes remaining"', time: "10:50", date: "2023-10-15" },
  { action: "Feedback Request", actionClass: "text-indigo-600", description: "Bot asked: 'Have all students arrived?'", time: "11:05", date: "2023-10-15" },
  { action: "Data Saving", actionClass: "text-teal-600", description: "Exam report saved", time: "11:30", date: "2023-10-15" }
];


const currentExamStudents = [
  { id: "2023001", name: "Dana Levi",       seat: "A1", status: "Not Arrived", extraTimeMinutes: 25 },
  { id: "2023002", name: "Noam Cohen",      seat: "A2", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023003", name: "Lior Mizrahi",    seat: "A3", status: "Not Arrived", extraTimeMinutes: 15 },
  { id: "2023004", name: "Yasmin Haddad",   seat: "A4", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023005", name: "Omer Avraham",    seat: "A5", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023006", name: "Maya Ben Haim",   seat: "A6", status: "Not Arrived", extraTimeMinutes: 20 },
  { id: "2023007", name: "Adam Faraj",      seat: "A7", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023008", name: "Rina Shalom",     seat: "A8", status: "Not Arrived", extraTimeMinutes: 15 },
  { id: "2023009", name: "Niv Azulay",      seat: "B1", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023010", name: "Salma Nassar",    seat: "B2", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023011", name: "Amit Shapira",    seat: "B3", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023012", name: "Maher Khoury",    seat: "B4", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023013", name: "Gal Itzhaki",     seat: "B5", status: "Not Arrived", extraTimeMinutes: 10 },
  { id: "2023014", name: "Rita Mor",        seat: "B6", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023015", name: "Yair Rahamim",    seat: "B7", status: "Not Arrived", extraTimeMinutes: 0 },
  { id: "2023016", name: "Hana Suleiman",   seat: "B8", status: "Not Arrived", extraTimeMinutes: 0 }
];

