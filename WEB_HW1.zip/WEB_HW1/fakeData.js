const examsData = [
  {
    id: 1,
    courseName: "Linear Algebra",
    courseNumber: "MATH101",
    date: "2025-01-12",
    time: "09:00",
    room: "B301",
    supervisor: "Majd Awad",
    studentsCount: 45
  },
  {
    id: 2,
    courseName: "Web Programming",
    courseNumber: "CS202",
    date: "2025-01-15",
    time: "13:00",
    room: "A204",
    supervisor: "Eli Cohen",
    studentsCount: 60
  },
  {
    id: 3,
    courseName: "Databases",
    courseNumber: "CS303",
    date: "2025-02-01",
    time: "10:00",
    room: "C112",
    supervisor: "Barak Levi",
    studentsCount: 50
  },
  {
    id: 4,
    courseName: "Operating Systems",
    courseNumber: "CS305",
    date: "2025-01-20",
    time: "11:00",
    room: "D210",
    supervisor: "Ayala Ben-David",
    studentsCount: 52
  },
  {
    id: 5,
    courseName: "Software Engineering",
    courseNumber: "CS310",
    date: "2025-01-22",
    time: "14:00",
    room: "A110",
    supervisor: "Yael Shalem",
    studentsCount: 47
  },
  {
    id: 6,
    courseName: "Machine Learning",
    courseNumber: "CS450",
    date: "2025-02-10",
    time: "14:00",
    room: "E102",
    supervisor: "Tamar Weiss",
    studentsCount: 35
  },
  {
    id: 7,
    courseName: "Computer Networks",
    courseNumber: "CS330",
    date: "2025-01-25",
    time: "08:30",
    room: "C210",
    supervisor: "Daniel Peretz",
    studentsCount: 48
  },
  {
    id: 8,
    courseName: "Data Structures",
    courseNumber: "CS220",
    date: "2025-01-28",
    time: "12:00",
    room: "B115",
    supervisor: "Eitan Mor",
    studentsCount: 55
  },
  {
    id: 9,
    courseName: "Software Testing",
    courseNumber: "CS340",
    date: "2025-02-14",
    time: "15:00",
    room: "A305",
    supervisor: "Maya Armon",
    studentsCount: 42
  },
  {
    id: 10,
    courseName: "Cyber Security",
    courseNumber: "CS480",
    date: "2025-02-18",
    time: "09:00",
    room: "F204",
    supervisor: "Noa Azulay",
    studentsCount: 38
  }
];
