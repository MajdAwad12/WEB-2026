// exams.js
// הצגת הבחינות בטבלה + חיפוש + בחירת תפקיד (Admin / Lecturer / Supervisor)

document.addEventListener("DOMContentLoaded", () => {
  const tableBody = document.getElementById("examsTableBody");
  const searchInput = document.getElementById("examSearchInput");
  const roleSelect = document.getElementById("roleSelect");

  let currentRole = "admin"; // ברירת מחדל

  //--------------------------------------
  // פונקציה שמחזירה בחינות לפי ROLE
  //--------------------------------------
  function getExamsForRole(role) {
    if (role === "admin") {
      // אדמין רואה את כל הבחינות
      return examsData;
    }

    if (role === "lecturer") {
      // מדגים מרצה ספציפי – אפשר לשנות שם בהמשך
      return examsData.filter(exam => exam.supervisor === "Yael Shalem");
    }

    if (role === "supervisor") {
      // מדגים משגיח ספציפי – אפשר לשנות שם בהמשך
      return examsData.filter(exam => exam.supervisor === "Eli Cohen");
    }

    return examsData;
  }

  //--------------------------------------
  // פונקציית רינדור טבלה
  //--------------------------------------
  function renderTable(data) {
    tableBody.innerHTML = "";

    data.forEach(exam => {
      const row = document.createElement("tr");
      row.classList.add("hover:bg-gray-50");

      row.innerHTML = `
        <td class="py-2 px-3">${exam.courseName}</td>
        <td class="py-2 px-3">${exam.courseNumber}</td>
        <td class="py-2 px-3">${exam.date}</td>
        <td class="py-2 px-3">${exam.time}</td>
        <td class="py-2 px-3">${exam.room}</td>
        <td class="py-2 px-3">${exam.supervisor}</td>
        <td class="py-2 px-3 text-right">${exam.studentsCount}</td>
      `;

      tableBody.appendChild(row);
    });

    // אם אין בחינות
    if (data.length === 0) {
      const emptyRow = document.createElement("tr");
      emptyRow.innerHTML = `
        <td colspan="7" class="py-4 px-3 text-center text-gray-400">
          No exams found.
        </td>
      `;
      tableBody.appendChild(emptyRow);
    }
  }

  //--------------------------------------
  // רינדור ראשוני (ADMIN)
  //--------------------------------------
  renderTable(getExamsForRole(currentRole));

  //--------------------------------------
  // חיפוש בתוך הנתונים של ROLE נוכחי
  //--------------------------------------
  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase().trim();

    // קודם סינון ROLE → אחר כך סינון חיפוש
    const roleFiltered = getExamsForRole(currentRole);

    const filtered = roleFiltered.filter(exam =>
      exam.courseName.toLowerCase().includes(query) ||
      exam.courseNumber.toLowerCase().includes(query)
    );

    renderTable(filtered);
  });

  //--------------------------------------
  // שינוי ROLE → מרענן את כל הטבלה
  //--------------------------------------
  roleSelect.addEventListener("change", () => {
    currentRole = roleSelect.value;

    // מנקה את שדה החיפוש בכל החלפת תפקיד
    searchInput.value = "";

    const filtered = getExamsForRole(currentRole);
    renderTable(filtered);
  });

});
