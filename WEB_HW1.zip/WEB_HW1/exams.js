// exams.js
// קוד להצגת הבחינות בטבלה + חיפוש בסיסי

document.addEventListener("DOMContentLoaded", () => {
  const tableBody = document.getElementById("examsTableBody");
  const searchInput = document.getElementById("examSearchInput");

  function renderTable(data) {
    tableBody.innerHTML = "";

    data.forEach(exam => {
      const row = document.createElement("tr");
      row.classList.add("hover:bg-gray-50");

      row.innerHTML = `
        <td class="py-2 px-3">${exam.courseName}</td>
        <td class="py-2 px-3">${exam.courseNumber}</td>
        <td class="py-2 px-3">${exam.date}</td>
        <td class="py-2 px-3">${exam.time}</td>
        <td class="py-2 px-3">${exam.room}</td>
        <td class="py-2 px-3">${exam.supervisor}</td>
        <td class="py-2 px-3 text-right">${exam.studentsCount}</td>
      `;

      tableBody.appendChild(row);
    });

    if (data.length === 0) {
      const emptyRow = document.createElement("tr");
      emptyRow.innerHTML = `
        <td colspan="7" class="py-4 px-3 text-center text-gray-400">
          No exams found.
        </td>
      `;
      tableBody.appendChild(emptyRow);
    }
  }

  // רינדור ראשוני
  renderTable(examsData);

  // חיפוש בסיסי
  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase().trim();

    const filtered = examsData.filter(exam =>
      exam.courseName.toLowerCase().includes(query) ||
      exam.courseNumber.toLowerCase().includes(query)
    );

    renderTable(filtered);
  });
});
