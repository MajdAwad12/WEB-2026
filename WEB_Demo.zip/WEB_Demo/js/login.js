// login.js
// Simple login logic using fakeAccounts from fakeData.js

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  const errorBox = document.getElementById("errorMessage");
  const errorText = document.getElementById("errorText");

  // ננקה משתמש ישן מהמערכת כשנכנסים למסך לוגין
  localStorage.removeItem("examApp_currentUser");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    // למצוא משתמש ב-fakeAccounts
    const user = fakeAccounts.find(
      acc => acc.username === username && acc.password === password
    );

    if (!user) {
      showError("Invalid username or password. Please try again.");
      shakeForm();
      return;
    }

    // נשמור ב-localStorage – כך שאר הדפים יכולים לדעת מי מחובר
    const userToStore = {
      username: user.username,
      fullname: user.fullname,
      role: user.role
    };

    // 👇 זה המפתח שכל שאר המסכים צריכים להשתמש בו
    localStorage.setItem("examApp_currentUser", JSON.stringify(userToStore));

    // כרגע כולם הולכים ל-dashboard.html
    window.location.href = "dashboard.html";
  });

  function showError(msg) {
    errorText.textContent = msg;
    errorBox.classList.remove("hidden");
  }

  function shakeForm() {
    const box = document.querySelector(".bg-white\\/95"); // ה-div של הטופס
    if (!box) return;
    box.classList.remove("shake");
    void box.offsetWidth; // לכפות reflow כדי שהאנימציה תרוץ שוב
    box.classList.add("shake");
  }
});
